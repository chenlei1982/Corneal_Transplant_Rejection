#define  PPP 1
#include <stdio.h>
#include  <math.h>
#include  <stdlib.h>
#include  <string.h>
FILE    *fopen(), *out4, *outt,  *outn,  *outm,  *outna,  *outnb,  *outl,  *outll,  *outlll;

/*------------------------------------------------------*/

main()
{
char     xx[1][200],x1[1][400],x3[1000][11], x44[1][30], x33[2][11];
int	  t2, t1, PP, PP2, PP1,  PP3, ii,blss, bls, ii1,p, j2, j22, jk, jk1, jk0, j1, p1, jjjkk, p2, jj[8000], t[10], j, k,kk, kkkk, i, kpc3;
int 	k1, k2, k3, k4, k5, k6, k7, QQ;
	
	

	  system("csh comd");
	
 }



