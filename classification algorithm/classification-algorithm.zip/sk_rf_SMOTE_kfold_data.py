# -*- coding: utf-8 -*-
"""
1. 分割数据集（交叉验证）
2. 分别训练数据
3. 合并预测结果
Date: 2023-08-19
"""
from argparse import ArgumentDefaultsHelpFormatter, ArgumentParser
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold, StratifiedKFold
from collections import Counter
from tqdm import tqdm
import pandas as pd
import time
import sys
import os

__author__ = 'Gardenia'

# 确保输出文件夹存在
output_dir = "outfile"
confusion_matrix_dir = "confusion_matrix"
label_test_data_dir = "label_test_data"
if not os.path.exists(output_dir):
    os.makedirs(output_dir)
if not os.path.exists(confusion_matrix_dir):
    os.makedirs(confusion_matrix_dir)
if not os.path.exists(label_test_data_dir):
    os.makedirs(label_test_data_dir)


def printContent(train, test, data):
    df_selected_train = pd.DataFrame(train, columns=data.iloc[:, :1].columns.tolist())
    df_selected_test = pd.DataFrame(test, columns=data.iloc[:, :1].columns.tolist())
    permutations_count_train = df_selected_train.groupby(list(df_selected_train.columns)).size().reset_index(
        name='count')
    permutations_count_test = df_selected_test.groupby(list(df_selected_test.columns)).size().reset_index(name='count')
    print("\n=== Number of samples after partitioned ===")
    print("\n Train DataSet ")
    print(permutations_count_train)
    print("\n Test DataSet ")
    print(permutations_count_test)


if __name__ == "__main__":
    parser = ArgumentParser(
        description="Multiple classifier integrates the feature sorting algorithm based on scikit-learn for prediction and output.",
        formatter_class=ArgumentDefaultsHelpFormatter)

    parser.add_argument("--datapath", type=str,
                        help="The path of dataset.", required=True)
    parser.add_argument("--clf", type=str,
                        help="The classifier. (svm / rf / knn / dt)", default='svm')
    parser.add_argument("--fold", type=int,
                        help="The fold of dataset.", required=True)
    parser.add_argument("--print", type=bool,
                        help="if print the  result of dataset.", required=False, default=False)
    parser.add_argument("-r", "--randomseed", type=int,
                        help="pseudo-random number generator state used for shuffling.", default=0)
    args = parser.parse_args()

    ### 划分 数据集
    dataPath = args.datapath    
    file_name = os.path.splitext(os.path.basename(dataPath))[0]
    # 加载数据集
    data = pd.read_csv(dataPath)
    df_selected = data.iloc[:, 0]
    permutations_count = df_selected.groupby(list(df_selected)).size().reset_index(name='count')
    label_number = len(permutations_count)
    # 加载 伪特征
    n = data.shape[0]
    # 将伪特征列插入到数据集的最后一列
    data.insert(1, 'Pseudo Feature', list(range(1, n + 1)))
    data.to_csv(f'{file_name}_data.csv', index=False)

    X = data.iloc[:, 1:].values
    characteristic_number = X.shape[1] - 1
    y = data.iloc[:, :1].values

    # Initialize 10-fold cross-validation
    kf = StratifiedKFold(n_splits=args.fold, shuffle=True, random_state=args.randomseed)

    # Split the dataset into train and test for each fold
    train_test_splits = []
    for train_index, test_index in kf.split(X, y):
        train, test = data.iloc[train_index], data.iloc[test_index]
        if args.print: printContent(train, test, data)
        train_test_splits.append((train, test))

    for i, (train, test) in enumerate(train_test_splits):
        # 保存到指定的输出文件
        train_filename = os.path.join(output_dir, f'{file_name}_train_{i + 1}.csv')
        test_filename = os.path.join(output_dir, f'{file_name}_test_{i + 1}.csv')

        train.to_csv(train_filename, index=False)
        test.to_csv(test_filename, index=False)

    ### 训练
    # 导入相关库
    import numpy as np
    from imblearn.over_sampling import SMOTE
    from sklearn.svm import SVC
    from sklearn.tree import DecisionTreeClassifier
    from sklearn.neighbors import KNeighborsClassifier
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import cross_val_predict, KFold
    from sklearn.metrics import accuracy_score, matthews_corrcoef, f1_score, precision_recall_fscore_support

    start_time = time.time()
    for i in range(1, args.fold + 1):
        train_path = os.path.join(output_dir, f'{file_name}_train_{i}.csv')
        test_path = os.path.join(output_dir, f'{file_name}_test_{i}.csv')
        # 读取数据
        df = pd.read_csv(train_path)
        # 设定分类信息和特征矩阵   去除伪特征
        X = df.iloc[:, 2:].values
        y = df.iloc[:, 0].values
        # y = df.iloc[:, 0].map(lambda x: x if x == 1 else 0)  # 调整正负样本标注(1正样本/0负样本)
        f_names = df.columns[2:].values
        # 不同 Class 统计 (根据 Target 列)
        print("\nDataset shape: ", X.shape, " Number of features: ", X.shape[1])
        num_categories = np.unique(y).size
        sum_y = np.asarray(np.unique(y.astype(int), return_counts=True))
        df_sum_y = pd.DataFrame(sum_y.T, columns=['Class', 'Sum'], index=None)
        print('\n', df_sum_y)
        # 综合采样
        smote = SMOTE(k_neighbors=2)
        X_resampled, y_resampled = smote.fit_resample(X, y)
        print("\n", smote)
        # 排序前后正负样本分布
        print("\nAfter SMOTE", sorted(Counter(y_resampled).items()))

        # 初始化 classifier 和预测结果字典
        clf_dict = {
            'rf': RandomForestClassifier(n_jobs=-1, random_state=args.randomseed),
            'knn': KNeighborsClassifier(n_jobs=-1),
            'svm': SVC(kernel='rbf', random_state=args.randomseed),
            'dt': DecisionTreeClassifier(random_state=args.randomseed)
        }

        y_pred_dict = dict().fromkeys(clf_dict.keys(), np.array([]))

        print('\nStarting training...')
        # 训练
        model = clf_dict[args.clf].fit(X_resampled, y_resampled)
        print('\n', model)
        print('\n', model.get_params())
        # 预测测试集
        print('\nStart predicting...')
        # 读取测试集数据
        df_test = pd.read_csv(test_path)
        # 设定分类信息和特征矩阵   去除伪特征
        X_test = df_test.iloc[:, 2:].values
        y_test = df_test.iloc[:, 0].values
        y_pred = model.predict(X_test)

        # 进行测试集模型评估
        from utils import model_evaluation, bi_model_evaluation

        # 进行测试集模型评估
        from utils import model_evaluation, bi_model_evaluation

        if (num_categories > 2):
            confusion_matrix = model_evaluation(num_categories, y_test, y_pred)
        else:
            confusion_matrix = bi_model_evaluation(y_test, y_pred)
        
        confusion_matrix.to_csv(os.path.join(confusion_matrix_dir, f'{file_name}_confusion_matrix_{i}.csv'))
        
        # 输出预测结果
        print("\n=== Predict Result Matrix ===\n")
        # 将真实样本和预测样本横向合并
        merged_sample = np.column_stack((y_test, y_pred))
        # 判断是否相等，相等为1，不等为0，并作为第三列
        merged_sample = np.column_stack((merged_sample, (merged_sample[:, 0] == merged_sample[:, 1]).astype(int)))
        merged_sample = pd.DataFrame(merged_sample, columns=['True', 'Prediction', 'isSuccess'])
        merged_sample.insert(2, "Pseudo Feature", df_test.iloc[:, 1].values)
        pd.set_option('display.max_rows', None)
        pd.set_option('display.max_columns', None)
        print(merged_sample)
        merged_sample.to_csv(os.path.join(label_test_data_dir, f'{file_name}_label_test_data_{i}.csv'))

    end_time = time.time()  # 程序结束时间
    print("\n[Finished in: {0:.6f} mins = {1:.6f} seconds]".format(
        ((end_time - start_time) / 60), (end_time - start_time)))

    ### 合并混淆矩阵
    # 创建一个初始的空混淆矩阵
    confusion_matrix_data = np.zeros((label_number, label_number + 1))

    # 循环处理每个文件
    for i in range(1, args.fold + 1):
        file_path = os.path.join(confusion_matrix_dir, f'{file_name}_confusion_matrix_{i}.csv')

        # 读取 Confusion Matrix 文件
        df = pd.read_csv(file_path)

        # 将读取的部分添加到总混淆矩阵中
        confusion_matrix_data = confusion_matrix_data + df.iloc[:, 1:].values

    # 打印总混淆矩阵
    header = ["Pred C" + str(i) for i in range(1, label_number + 1)]
    confusion_matrix_data = confusion_matrix_data[:, :-1]
    confusion_matrix_sum = pd.DataFrame(confusion_matrix_data, columns=header)
    pd.set_option('display.max_rows', None)
    pd.set_option('display.max_columns', None)
    pd.set_option('display.max_colwidth', None)
    pd.set_option('display.float_format', '{:.0f}'.format)
    np.set_printoptions(formatter={'float': lambda x: "{:.0f}".format(x)})
    confusion_matrix_sum = confusion_matrix_sum.astype(int)
    confusion_matrix_sum.to_csv(os.path.join(confusion_matrix_dir, f'{file_name}_confusion_matrix_sum.csv'), index=False, header=False, sep=' ')
    print("\n=== Confusion Matrix Combination ===\n")
    print(confusion_matrix_sum)

    ### 合并测试标签
    label_test_data = []

    # 循环处理每个文件
    for i in range(1, args.fold + 1):
        file_path = os.path.join(label_test_data_dir, f'{file_name}_label_test_data_{i}.csv')

        # 读取CSV文件
        df = pd.read_csv(file_path)

        np_data = df.iloc[:, 1:].values
        if len(label_test_data) == 0:
            label_test_data = np_data.copy()
        else:
            label_test_data = np.concatenate((label_test_data, np_data), axis=0)

    header = ["True", "Prediction", "Pseudo Feature", "isSuccess"]
    label_test_data = pd.DataFrame(label_test_data, columns=header)
    pd.set_option('display.max_rows', None)
    pd.set_option('display.max_columns', None)
    pd.set_option('display.max_colwidth', None)
    pd.set_option('display.float_format', '{:.0f}'.format)
    np.set_printoptions(formatter={'float': lambda x: "{:.0f}".format(x)})
    print("\n=== Label Test Data Combination ===\n")
    print(label_test_data)

    label_test_data.to_csv(os.path.join(label_test_data_dir, f'{file_name}_label_test_data.csv'), index=False)
